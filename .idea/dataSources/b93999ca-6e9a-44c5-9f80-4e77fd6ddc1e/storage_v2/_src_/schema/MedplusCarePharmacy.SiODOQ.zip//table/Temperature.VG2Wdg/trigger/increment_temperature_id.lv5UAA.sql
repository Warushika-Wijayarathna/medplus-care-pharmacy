create definer = root@localhost trigger increment_temperature_id
    before insert
    on Temperature
    for each row
BEGIN
    UPDATE AutoIncrement_Temperature SET next_id = next_id + 1;
    SET NEW.temp_id = CONCAT('TE', LPAD((SELECT next_id FROM AutoIncrement_Prescription), 5, '0'));
END;

