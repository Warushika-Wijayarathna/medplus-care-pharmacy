create definer = root@localhost trigger increment_item_id
    before insert
    on Item
    for each row
BEGIN
    UPDATE AutoIncrement_Item SET next_id = next_id + 1;
    SET NEW.item_id = CONCAT('I', LPAD((SELECT next_id FROM AutoIncrement_Item), 4, '0'));
END;

