create definer = root@localhost trigger increment_report_id
    before insert
    on Report
    for each row
BEGIN
    UPDATE AutoIncrement_Report SET next_id = next_id + 1;
    SET NEW.r_id = CONCAT('R', LPAD((SELECT next_id FROM AutoIncrement_Report), 4, '0'));
END;

