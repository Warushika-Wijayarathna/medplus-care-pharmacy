create definer = root@localhost trigger increment_payment_id
    before insert
    on Payment
    for each row
BEGIN
    UPDATE AutoIncrement_Payment SET next_id = next_id + 1;
    SET NEW.pay_id = CONCAT('P', LPAD((SELECT next_id FROM AutoIncrement_Payment), 4, '0'));
END;

