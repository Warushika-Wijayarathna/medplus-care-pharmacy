create definer = root@localhost trigger increment_test_id
    before insert
    on Test
    for each row
BEGIN
    UPDATE AutoIncrement_Test SET next_id = next_id + 1;
    SET NEW.test_id = CONCAT('T', LPAD((SELECT next_id FROM AutoIncrement_Test), 4, '0'));
END;

