create definer = root@localhost trigger increment_user_id
    before insert
    on User
    for each row
BEGIN
    UPDATE AutoIncrement_User SET next_id = next_id + 1;
    SET NEW.usr_id = CONCAT('U', LPAD((SELECT next_id FROM AutoIncrement_User), 4, '0'));
END;

