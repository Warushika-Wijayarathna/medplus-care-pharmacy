create definer = root@localhost view DailyProfitView as
select cast(`o`.`date` as date)                                           AS `sale_date`,
       sum((`oid`.`qty` * (`i`.`retail_price` - `i`.`whole_sale_price`))) AS `daily_profit`
from ((`MedplusCarePharmacy`.`order_item_detail` `oid` join `MedplusCarePharmacy`.`Order` `o`
       on ((`oid`.`o_id` = `o`.`o_id`))) join `MedplusCarePharmacy`.`Item` `i` on ((`oid`.`item_id` = `i`.`item_id`)))
group by cast(`o`.`date` as date);

